import Link from "next/link";
import { HomeIcon } from "@heroicons/react/24/outline";

// Not Found page for app/ (root level)
// This component handles 404 errors for routes that don't exist in the main app

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 px-4">
      <div className="text-center">
        {/* Icon */}
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-blue-500 rounded-full blur-lg opacity-30 animate-pulse"></div>
            <div className="relative bg-blue-500 rounded-full p-4">
              <HomeIcon className="h-12 w-12 text-white" />
            </div>
          </div>
        </div>

        {/* 404 Number */}
        <h1 className="text-9xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 animate-pulse">
          404
        </h1>

        {/* Message */}
        <h2 className="mt-4 text-3xl font-bold text-gray-900 dark:text-white">
          Página no encontrada
        </h2>
        <p className="mt-4 text-lg text-gray-600 dark:text-gray-300 max-w-md mx-auto">
          La página que buscas no existe o ha sido movida. No te preocupes, te
          ayudamos a encontrar lo que necesitas.
        </p>

        {/* Action Button */}
        <Link
          href="/"
          className="mt-8 inline-flex items-center gap-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 px-8 py-4 text-lg font-semibold text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
        >
          <HomeIcon className="h-6 w-6" />
          Volver al inicio
        </Link>

        {/* Decorative elements */}
        <div className="mt-12 flex justify-center space-x-4">
          <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce"></div>
          <div
            className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"
            style={{ animationDelay: "0.1s" }}
          ></div>
          <div
            className="w-3 h-3 bg-indigo-400 rounded-full animate-bounce"
            style={{ animationDelay: "0.2s" }}
          ></div>
        </div>
      </div>
    </main>
  );
}
