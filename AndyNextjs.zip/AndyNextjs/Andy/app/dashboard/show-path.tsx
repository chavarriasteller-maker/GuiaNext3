"use client";

import { usePathname, useSearchParams } from "next/navigation";

export default function ShowPath() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const search = searchParams?.toString();

  if (!pathname)
    return (
      <span className="text-gray-800 dark:text-gray-100">Unknown path</span>
    );

  return (
    <span className="text-gray-800 dark:text-gray-100">
      {pathname}
      {search ? `?${search}` : ""}
    </span>
  );
}
