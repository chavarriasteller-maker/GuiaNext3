import Link from "next/link";
import { FaceFrownIcon } from "@heroicons/react/24/outline";
import ShowPath from "./show-path";

export default function NotFound() {
  return (
    <main className="flex h-full flex-col items-center justify-center gap-2">
      <FaceFrownIcon className="w-10 text-gray-400" />
      <h2 className="text-xl font-semibold">404 - Página no encontrada</h2>
      <p>No se pudo encontrar la página solicitada:</p>
      <div className="font-mono text-sm bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100 p-2 rounded">
        <ShowPath />
      </div>
      <Link
        href="/dashboard"
        className="mt-4 rounded-md bg-blue-500 px-4 py-2 text-sm text-white transition-colors hover:bg-blue-400"
      >
        Volver al panel
      </Link>
    </main>
  );
}
