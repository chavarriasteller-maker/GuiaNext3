import { ReactNode } from "react";
import SideNav from "@/app/ui/dashboard/sidenav";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: {
    template: "%s | Panel",
    default: "Panel",
  },
  description: "Panel principal de la aplicación.",
};

export const experimental_ppr = true;

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen flex-col md:flex-row md:overflow-hidden">
      <div className="w-full flex-none md:w-64">
        <SideNav />
      </div>
      <main
        data-id="dashboard-main"
        className="flex-grow p-6 md:overflow-y-auto md:p-12"
      >
        {children}
      </main>
    </div>
  );
}
