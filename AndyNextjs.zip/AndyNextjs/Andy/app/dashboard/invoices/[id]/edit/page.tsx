import Form from "@/app/ui/invoices/edit-form";
import Breadcrumbs from "@/app/ui/invoices/breadcrumbs";
import { fetchInvoiceById, fetchCustomers } from "@/app/lib/data";
import { notFound } from "next/navigation";

import { Metadata, Viewport } from "next";

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#111827" },
  ],
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: "Editar factura",
  description: "Editar una factura existente",
  manifest: "/site.webmanifest",
  appleWebApp: {
    title: "Editar factura",
    statusBarStyle: "default",
    capable: true,
  },
  keywords: ["facturas", "editar", "facturación"],
  authors: [{ name: "Federico" }],
  robots: "index, follow",
};

export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const [invoice, customers] = await Promise.all([
    fetchInvoiceById(id),
    fetchCustomers(),
  ]);

  if (!invoice) {
    notFound();
  }

  return (
    <main className="bg-white dark:bg-gray-900 min-h-screen">
      <Breadcrumbs
        breadcrumbs={[
          { label: "Facturas", href: "/dashboard/invoices" },
          {
            label: "Editar factura",
            href: `/dashboard/invoices/${id}/edit`,
            active: true,
          },
        ]}
      />
      <Form invoice={invoice} customers={customers} />
    </main>
  );
}
