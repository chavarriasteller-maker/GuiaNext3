import Form from "@/app/ui/invoices/create-form";
import Breadcrumbs from "@/app/ui/invoices/breadcrumbs";
import { fetchCustomers } from "@/app/lib/data";
import { Metadata, Viewport } from "next";

export const dynamic = "force-dynamic";

export const viewport: Viewport = {
  themeColor: "#ffffff",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: "Crear factura",
  description: "Crear una nueva factura",
  manifest: "/site.webmanifest",
  appleWebApp: {
    title: "Crear factura",
    statusBarStyle: "default",
    capable: true,
  },
  keywords: ["facturas", "crear", "facturación"],
  authors: [{ name: "Federico" }],
  robots: "index, follow",
};

export default async function Page() {
  const customers = await fetchCustomers();

  return (
    <main>
      <Breadcrumbs
        breadcrumbs={[
          { label: "Facturas", href: "/dashboard/invoices" },
          {
            label: "Crear factura",
            href: "/dashboard/invoices/create",
            active: true,
          },
        ]}
      />
      <Form customers={customers} />
    </main>
  );
}
