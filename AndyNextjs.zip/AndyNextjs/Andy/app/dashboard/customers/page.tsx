import { Metadata, Viewport } from "next";
import { Suspense } from "react";

export const dynamic = "force-dynamic";

export const viewport: Viewport = {
  themeColor: "#ffffff",
};

export const metadata: Metadata = {
  title: "Clientes",
  description: "Esta página muestra información de clientes.",
  openGraph: {
    title: "Clientes",
    description: "Esta página muestra información de clientes.",
    images: ["/customers-opengraph-image.jpg"],
  },
};

import { fetchCustomers } from "@/app/lib/data";
import CustomersTable from "@/app/ui/customers/table";

export default async function Page() {
  const customers = await fetchCustomers();

  return (
    <main>
      <Suspense
        fallback={<div className="animate-pulse">Cargando clientes...</div>}
      >
        <CustomersTable customers={customers} />
      </Suspense>
    </main>
  );
}
