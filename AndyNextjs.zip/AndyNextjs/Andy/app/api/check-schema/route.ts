import postgres from "postgres";

const sql = postgres(process.env.POSTGRES_URL!, { ssl: "require" });

export async function GET() {
  try {
    // Query to get all schemas in the database
    const schemas = await sql`
      SELECT schema_name
      FROM information_schema.schemata
      ORDER BY schema_name;
    `;

    // Query to get all tables in the 'dashboard' schema specifically
    const dashboardTables = await sql`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'dashboard'
      ORDER BY table_name;
    `;

    // Query to get all tables in the 'public' schema
    const publicTables = await sql`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
      ORDER BY table_name;
    `;

    return Response.json({
      allSchemas: schemas.map((s) => s.schema_name),
      dashboardSchemaExists: schemas.some((s) => s.schema_name === "dashboard"),
      dashboardTables: dashboardTables.map((t) => t.table_name),
      publicTables: publicTables.map((t) => t.table_name),
    });
  } catch (error) {
    console.error("Database Error:", error);
    return Response.json({ error: String(error) }, { status: 500 });
  }
}
