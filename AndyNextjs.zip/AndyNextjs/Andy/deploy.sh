#!/bin/bash
(
echo ""
echo "n"
echo "learn-nextjs-dashboard"
echo "./"
echo "n"
echo "n"
echo "n"
) | vercel deploy --prod --yes
