# Esquema de la Base de Datos - Dashboard

## Información General

- **Nombre del proyecto**: `neon-indigo-kite` (anteriormente `neon-nextjs-dashboard`)
- **ID del proyecto**: `wispy-poetry-52762475`
- **Base de datos**: `neondb`
- **Región**: aws-eu-west-2 (Europa)
- **Branch**: `main` (br-broad-union-abfa4pb3)
- **Usuario**: `neondb_owner`
- **Host**: `ep-aged-night-ab7l7nwr-pooler.eu-west-2.aws.neon.tech`

## Migración Realizada

Se ha migrado el esquema `dashboard` del proyecto `neon-nextjs-dashboard` al proyecto `neon-indigo-kite`. La migración incluyó:

1. Creación del esquema `dashboard` en el proyecto `neon-indigo-kite`
2. Creación de las tablas `customers`, `invoices` y `revenue` en el esquema `dashboard`
3. Creación de la tabla `users` en el esquema `public`
4. Migración de todos los datos de las tablas
5. Actualización del archivo `.env` para apuntar al nuevo proyecto
6. Actualización del código fuente para usar el esquema explícito en las consultas SQL

## Esquemas

### Esquema `dashboard`

Contiene las tablas principales de la aplicación de dashboard.

#### Tabla `customers` - Clientes

| Columna   | Tipo    | Nullable | Default           | Descripción                     |
| --------- | ------- | -------- | ----------------- | ------------------------------- |
| id        | uuid    | NO       | gen_random_uuid() | Identificador único del cliente |
| name      | varchar | NO       | -                 | Nombre del cliente              |
| email     | varchar | NO       | -                 | Email del cliente               |
| image_url | varchar | NO       | -                 | URL de la imagen del cliente    |

**Índices**:

- `customers_pkey` - PRIMARY KEY (id)

**Datos**: 6 clientes

#### Tabla `invoices` - Facturas

| Columna     | Tipo    | Nullable | Default           | Descripción                         |
| ----------- | ------- | -------- | ----------------- | ----------------------------------- |
| id          | uuid    | NO       | gen_random_uuid() | Identificador único de la factura   |
| customer_id | uuid    | NO       | -                 | ID del cliente (FK hacia customers) |
| amount      | integer | NO       | -                 | Monto de la factura (en centavos)   |
| status      | varchar | NO       | -                 | Estado: 'pending' o 'paid'          |
| date        | date    | NO       | -                 | Fecha de la factura                 |

**Índices**:

- `invoices_pkey` - PRIMARY KEY (id)

**Datos**: 10 facturas

#### Tabla `revenue` - Ingresos

| Columna | Tipo    | Nullable | Default | Descripción      |
| ------- | ------- | -------- | ------- | ---------------- |
| month   | varchar | NO       | -       | Mes del reporte  |
| revenue | integer | NO       | -       | Ingresos del mes |

**Índices**:

- `revenue_month_key` - UNIQUE (month)

**Datos**: 12 registros (uno por cada mes del año)

### Esquema `public`

Contiene la tabla de usuarios para autenticación.

#### Tabla `users` - Usuarios

| Columna  | Tipo    | Nullable | Default           | Descripción                     |
| -------- | ------- | -------- | ----------------- | ------------------------------- |
| id       | uuid    | NO       | gen_random_uuid() | Identificador único del usuario |
| name     | varchar | NO       | -                 | Nombre del usuario              |
| email    | text    | NO       | -                 | Email del usuario               |
| password | text    | NO       | -                 | Contraseña hasheada del usuario |

**Índices**:

- `users_pkey` - PRIMARY KEY (id)
- `users_email_key` - UNIQUE (email)

**Datos**: 1 usuario

**Usuario Demo**:

- Email: `user@nextmail.com`
- Password: `123456`

## Cambios en el Código

Se actualizaron los siguientes archivos para usar el esquema explícito:

1. **`.env`**: Actualizado para apuntar al nuevo proyecto `neon-indigo-kite`
2. **`app/lib/data.ts`**: Todas las consultas SQL ahora usan `dashboard.` explícitamente
3. **`app/lib/actions.ts`**: Todas las consultas SQL ahora usan `dashboard.` explícitamente
4. **`auth.ts`**: Consulta de usuario ahora usa `public.users` explícitamente

## Notas

- Todas las tablas usan UUID como identificadores primarios
- Los montos en `invoices` se almacenan en centavos (integer)
- La tabla `users` se usa para autenticación con NextAuth.js
- La tabla `revenue` almacena datos agregados para el dashboard
- Las consultas SQL en el código ahora especifican el esquema explícitamente para evitar conflictos con otros esquemas en la misma base de datos
